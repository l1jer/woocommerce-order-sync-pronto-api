<?php
// This file handles plugin uninstallation

if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

// Clean up operations, options, or other data related to this plugin